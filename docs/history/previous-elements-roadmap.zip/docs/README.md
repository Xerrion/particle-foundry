# Particle Foundry documentation

**Developer entrypoint: [START_HERE.md](START_HERE.md). Start implementation at P1 / M0.**

| Document | Purpose |
| --- | --- |
| [Roadmap](roadmap.md) | Canonical P1-P9 delivery sequence, beginning with GPU redesign |
| [Remaining work](remaining-work.md) | Active milestone tracker and historical-status boundaries |
| [Current model](model.md) | Documented legacy behavior, limits, and target-model contracts |
| [Elements](elements.md) | Eight legacy models plus the complete 118-element delivery roster |
| [Matter architecture](architecture/matter-model.md) | Elements, nuclides, species, materials, mixtures, and GPU storage |
| [Project structure](project-structure.md) | Existing module ownership and proposed additions |
| [GPU redesign](plans/fluid-gpu-redesign/plan.md) | M0-M7 CPU reference, WebGPU port, integration, and promotion |
| [Pressure waves and breakage](plans/pressure-waves-breakage/plan.md) | W0-W4 compressible model and solid failure |
| [Materials and chemistry](plans/materials-and-chemistry/plan.md) | C0-C9 data pipeline, core 40, compounds, and expansion to 83 |
| [Nuclear simulation](plans/nuclear-simulation/plan.md) | N0-N8 decay, radiation, fusion/fission, and exotic coverage |
| [Acceptance](validation/acceptance.md) | Tests, evidence, thresholds, and final Q0-Q2 release gates |
| [Sources](sources.md) | Scientific/API sources, scope, and provenance rules |
| [Change log](CHANGELOG.md) | What changed in this documentation package |
| [Original evidence](history/README.md) | Unmodified input archive and historical audit boundaries |

Machine-readable planning data: [element roster](data/element-roadmap.json), [roster schema](data/element-roadmap.schema.json), and [development phases](data/development-phases.json). These are not a runtime material database.

From the repository or extracted package root:

```sh
python docs/scripts/validate-docs.py
```

This validates documentation structure, manifest coverage, local links, generated HTML freshness, and preserved evidence. It does not compile the game, validate physical constants, or run GPU tests.
