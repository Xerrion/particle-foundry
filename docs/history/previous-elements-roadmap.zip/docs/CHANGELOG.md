# Documentation change log

## 21 September 2026: GPU-first roadmap and all-element/nuclear expansion

This is a documentation revision made from the supplied archive. It does not implement the simulation, run the application test suite, reproduce the numerical audit, or measure GPU hardware.

### Added

- `START_HERE.md`: one developer entrypoint, copy-paste implementation brief, first M0-M3 work slice, and continuation through all P1-P9 phases.
- A canonical phase manifest and exact 118-element JSON roster/schema with 40/43/20/15 cohorts and cumulative targets 40/83/103/118.
- Matter architecture separating element, nuclide, chemical species, material form, recipe, component population and physical state.
- Materials/chemistry C0-C9 plan, including essential compounds, partial concentrations, shared material mechanisms, and source-qualified support.
- Nuclear N0-N8 plan, including decay, radiation, explicit fusion/fission networks, mass/energy conventions, supported host coupling, and exotic creative-mode behavior.
- Cross-phase acceptance and Q0-Q2 release gates, a milestone evidence template, source register, documentation index, and validation/rendering scripts.
- Exact original input archive and per-file hashes for historical preservation.

### Updated existing documentation

- Replaced the old partly delivered phase ordering with a GPU-first P1-P9 implementation roadmap while retaining original legacy history in the preserved archive.
- Rewrote the current model and active backlog in English, qualifying source/test claims as reported by the supplied documentation.
- Retained the eight element-model specifications and their original constants/limits; added complete cohort tables and separate material/chemical/nuclear/creative support semantics.
- Corrected the stale five-element reference and the implication that no element had any implemented model. The documented legacy count is eight; the other 110 identities are reference-only there.
- Extended GPU M1 with the minimal identity/storage contract needed by later chemistry and nuclear work. The M3 demonstrator scope remains unchanged.
- Clarified active-component GPU storage, snapshot/network versioning, explicit capacity failures, and physical-model versus execution-backend selection.
- Added W0-W4 IDs to the pressure/breakage plan and requirements to retain composition through fragments and later source coupling.
- Qualified the historical audit as historical; a fresh M0 run must compare against, not overwrite or force, its 24-pass/11-fail result.
- Regenerated the GPU HTML view from the revised Markdown, removing stale paths and independently drifting presentation text.

### Preserved unchanged

`plans/fluid-gpu-redesign/audit.cjs`, `current-audit-output.txt`, and `current-audit-results.json` are byte-for-byte unchanged. The full input is preserved in `history/original-docs-2026-09-21.zip`. Its source provenance, tool versions, numbers and old path labels were not rewritten.

### Interpretation corrections

The 40/83/103/118 milestones are development cohorts, not stable-element classifications or claims that every identity has measured bulk properties. Unknown data stays unknown; predicted data and fictional gameplay values have different labels. Nuclear channels use nuclides and states, not one element-level radioactive flag. A reaction network does not imply a validated plasma, reactor or shock model.

### Verification scope

The delivered package is checked for local documentation links/anchors, roster identity/count consistency, phase ordering, JSON schema validity, generated HTML freshness, archive integrity, and preservation of original audit bytes. Application tests and physical/GPU validation remain the developer's phase work.
