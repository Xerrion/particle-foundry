# Project structure

**Revision:** 21 September 2026. Existing paths below are reported by the supplied documentation, not inspected application source. Start at [START_HERE.md](START_HERE.md). Proposed additions are clearly separated below.

The project groups code by responsibility. Source and test filenames use lowercase
kebab-case; tests use the `.test.ts` suffix. `README.md` stays at the repository root
with the package, TypeScript, Vite, and Biome configuration files.

```text
index.html                  Vite HTML entry point
src/
  main.ts                   Browser startup and animation loop
  app/                      DOM controls and viewport navigation
  materials/                Catalogue, validation, IDs and reference data
  physics/                  Physical solvers and reaction rules
  rendering/                Canvas rendering, field maps and visual effects
  scenes/                   Initial scene construction
  simulation/               World state, orchestration, clock and diagnostics
  styles/                   Application styles
  tools/                    Painting and editing tools
tests/
  app/                      DOM controls and pointer/viewport tests
  integration/              Cross-system scenarios and model regressions
  materials/                Catalogue and element-reference tests
  physics/                  Solver and reaction tests
  rendering/                Renderer and visual-effect tests
  simulation/               World state and clock tests
  tools/                    Brush and ignition-tool tests
  fixtures/                 Shared deterministic scene builders
  types/                    Compile-time catalogue checks
benchmarks/                 Reproducible performance workloads
docs/
  START_HERE.md             Developer entrypoint; start at P1 / GPU M0
  README.md                 Documentation index
  model.md                  Current physical model and planned extensions
  elements.md               Supported element models and limitations
  roadmap.md                Delivery sequence
  remaining-work.md         Active backlog and delivered history
  architecture/             Matter identities, composition, and GPU storage
  data/                     Element roster and phase planning manifests
  validation/               Cross-phase acceptance and final release gates
  templates/                Milestone evidence template
  scripts/                  Documentation validation and HTML generation
  sources.md                Source register and provenance policy
  CHANGELOG.md              Documentation changes
  history/                  Exact input archive and original hashes
  plans/                    Implementation proposals and their audit evidence
artifacts/                  Ignored local output; not application source
  archives/                 Source archives
  browser/                  Browser captures
  logs/                     Local check logs
  profiles/                 CPU profiles and reports
  snapshots/                Historical verification workspaces
```

## Module ownership

- `simulation/world.ts` owns mutable simulation state. `simulation/physics.ts`
  orders the solvers; `simulation/sandbox.ts` composes the public application API.
- `physics/` implements model behavior using world state and material definitions.
  Browser and DOM access belong in `app/` and `main.ts`.
- `app/controls.ts` coordinates input using a focused command/readings contract.
  `material-picker.ts` owns catalogue filtering and selection, `view-controls.ts`
  owns field toggles and legends, and `pointer-mapping.ts` contains pure coordinate
  conversion. The picker and view controls receive only the callbacks they use.
  `dom.ts` provides the shared required-element lookup with descriptive failures.
- `materials/definitions.ts` is the single material catalogue. Import its public
  API through `materials/index.ts` (the `materials` directory import). `ids.ts`,
  `physical-properties.ts`, and `presentation.ts` retain the existing focused
  re-export interfaces; they do not own duplicate catalogue data.
- `materials/queries.ts` owns catalogue-derived phase classification and motion
  profiles. Rendering, diagnostics, and physical solvers query material properties
  without importing the movement solver. Lookup arrays stay private; the shared
  motion-profile lookup is frozen.
- `rendering/` reads physical state. Its visual effects must not mutate occupancy
  or the physical energy budget.
- `tools/` handles user edits and their source accounting; `scenes/` builds initial
  conditions. Keep shared test scenes in `tests/fixtures/`.

Use relative imports and keep descriptive module names. Add a subdirectory when a
domain grows into multiple related modules; do not introduce generic `utils/` or
duplicate state to make an import shorter. The future CPU/GPU backend layout remains
specified in the [fluid redesign plan](plans/fluid-gpu-redesign/plan.md).

## Engineering conventions

- Prefer the simplest implementation for current requirements. Do not add future
  GPU interfaces, extension registries, generic frameworks, or inheritance trees
  before a concrete caller needs them. GPU M1 now supplies a concrete caller for the minimal backend and matter-identity contracts; this does not authorize implementing future nuclear machinery early.
- Group behavior that changes together. Compose small functions and focused
  contracts at UI/domain boundaries; consumers should require only operations they
  use. Implementations must preserve their contract's guarantees and failure modes.
- Keep material knowledge in the catalogue and simulation state in its existing
  owner. Centralize repeated rules when callers share the same meaning, not merely
  similar-looking code. Add catalogue entries for existing behavior rather than
  modifying every consumer.
- Prefer readonly input types and detached readings. Keep mutable hot-path arrays
  inside the simulation boundary and private caches inside their owning module;
  do not create a second authority to simplify UI access.
- Validate public input before indexing or mutating. `World.indexAt()` is the
  shared safe-integer and bounds check for cell readings and dynamic-cell commands.
  Brush commands intentionally have a different contract: valid outside strokes
  are ignored. Preserve these documented differences.
- Use explicit domain types and readable control flow. Repeated setters and reset
  commands should have predictable results; physics steps and paint sources remain
  intentionally state-changing operations.
- Diagnose failures with contextual errors and existing physical diagnostics.
  Avoid per-cell logging and hidden state repair. Test behavior at module boundaries
  and add regression tests for demonstrated defects.
- Keep refactors scoped, preserve unrelated working changes, and run the relevant
  checks. Record planned capabilities separately from implemented behavior.

## Checks and historical evidence

Run `bun run lint`, `bun run check`, and `bun run build` from the repository root.
`bun run test` explicitly discovers `tests/`; Biome excludes `artifacts/` so old
verification snapshots cannot introduce duplicate tests or nested configuration.

CPU profile reports, audit output, and source hashes preserve their original paths
and line numbers as historical evidence. They are not rewritten to imply that a
measurement was repeated after the directory change. The executable audit harness
is preserved, and its build instructions in the fluid plan target the new paths.

Local artifacts were moved without deleting their contents. They are ignored by
Git; durable project documentation and numerical audit evidence stay under `docs/`.


## Proposed phased additions, not existing code

Keep the current material catalogue's public entrypoint and single authored source of material knowledge. New modules separate responsibilities behind it; they must not create competing handwritten CPU/GPU catalogues.

| Phase | Proposed source ownership | Proposed validation surfaces |
| --- | --- | --- |
| P1 / M1 | `src/simulation/backend.ts`, `src/fluid/state.ts`; minimal IDs/adapters under `src/matter/` | Backend commands, snapshot migration, identity/ownership tests |
| P1 / M2-M3 | `src/fluid/cpu/`, `src/fluid/gpu/`, shared operator contracts, `src/rendering/gpu-renderer.ts` | `tests/fluid/`, browser GPU fixtures, allocation/transfer benchmarks |
| P1 / M4-M7 | `src/thermodynamics/`, `src/granular/`, bounded circuit adapter | Closure, venting, phase, contention, recovery and product tests |
| P2 | `src/compressible/`, `src/solids/` or focused existing-physics submodules | Shock/reference, traction, fracture, and equal-time parity fixtures |
| P3-P5 | `src/matter/`, `src/chemistry/`, `scripts/data/`, shared table compiler | Catalogue/schema, source domains, atoms/charge, partial concentrations, capacity tests |
| P6-P8 | `src/nuclear/`, `src/radiation/`, versioned network/data preparation | Decay/reaction populations, radiation energy, daughter closure and mode/recovery tests |
| P9 | Existing app, scene, persistence and diagnostics owners | Combined-feature browser tests, long-session and target-device runs |

Create these only when needed by a milestone. A CPU numerical reference and GPU implementation share definitions, units, equations, stages, and fixtures, but not an evolving world instance. Keep rendering/probes read-only. CPU metadata/data compilation is not a second simulation authority.

Composition belongs to the backend-owned state through the [matter contract](architecture/matter-model.md). Chemistry, nuclear, and radiation modules apply validated source transactions at declared stage boundaries. Do not introduce a second whole-world owner or synchronize legacy parcel transport with GPU transport every tick.

The [GPU plan](plans/fluid-gpu-redesign/plan.md), [materials plan](plans/materials-and-chemistry/plan.md), and [nuclear plan](plans/nuclear-simulation/plan.md) define the contracts before their corresponding source changes. New evidence belongs under a run-specific `artifacts/validation/` path; durable summaries and dataset manifests belong in version-controlled documentation.
