# Start here: developer implementation entrypoint

**Project:** Particle Foundry  
**Plan revision:** 21 September 2026  
**First work item:** P1 / M0, the fluid and GPU redesign baseline  
**Status:** implementation instructions, not a claim that any new phase is delivered.

Implement the complete roadmap in order. Start with the GPU redesign, not with adding element brushes to the old parcel engine. Within that redesign, build and validate a small CPU reference before porting the same equations to WebGPU. The CPU reference is part of the GPU work, not a separate competing architecture.

This package contains documentation and the supplied historical audit, not the application source. Inspect the actual repository before editing it. The uploaded documentation reports eight implemented legacy element models; no source, test suite, benchmark, or GPU run was executed for this documentation revision. The retained audit is historical evidence, not a fresh result.

## Copy-paste developer brief

```text
Use docs/START_HERE.md as the authoritative implementation entrypoint.
Implement Particle Foundry's P1-P9 roadmap in order, beginning with GPU milestone M0.
Read the existing source and preserve all working-tree changes before editing.
For P1, follow docs/plans/fluid-gpu-redesign/plan.md and complete M0-M7.
Do not port the old cellular transport directly to shaders.
First validate the conservative CPU reference; then implement equivalent WebGPU stages.
Use docs/architecture/matter-model.md for the minimal M1 identity/storage contract.
Keep the first GPU demonstrator limited to one liquid, carrier gas, and fixed walls.
Do not implement the full chemistry or nuclear systems before their phases.
Keep one authoritative state and one transport owner per scene.
Use docs/roadmap.md for phase order and docs/remaining-work.md for work-item tracking.
Use the element manifest for all 118 identities and the 40/83/103/118 delivery cohorts.
Complete each phase's tests, evidence, documentation, and acceptance gate before promotion.
Continue to the next dependency-ready milestone; do not stop after another planning document.
Never mark planned work as complete, conceal unsupported physics, or fabricate measurements.
If a real blocker remains, record the exact blocker and completed work without corrupting state.
```

## Read in this order

1. [Roadmap](roadmap.md) and [active work](remaining-work.md): the full sequence and exit gates.
2. [Current model](model.md) and [project structure](project-structure.md): documented legacy behavior and source ownership. Confirm both against the checkout.
3. [Fluid/GPU plan](plans/fluid-gpu-redesign/plan.md): M0-M7, numerical contracts, audit commands, and recovery.
4. [Matter model](architecture/matter-model.md): implement only its M1 subset initially. Read the full [materials plan](plans/materials-and-chemistry/plan.md) and [nuclear plan](plans/nuclear-simulation/plan.md) to avoid dead-end interfaces, not to enlarge M3.

Use [acceptance](validation/acceptance.md) for evidence requirements and [sources](sources.md) for data provenance. The Markdown plans are canonical. The GPU [HTML view](plans/fluid-gpu-redesign/plan.html) is generated from its Markdown, not independently maintained.

## First development slice: P1, M0 through M3

### M0: establish what actually exists

Inspect repository instructions, `package.json`, the lockfile, source layout, tests, and current Git state. Preserve tracked and untracked work in a recoverable snapshot before changing anything. A patch alone does not preserve untracked files. Do not reset, clean, or replace the working tree with the historical commit mentioned by the audit.

From the actual repository root, inspect then run its existing checks:

```sh
git status --short
git diff --stat
bun run lint
bun run check
bun run test
bun run build
```

These commands are documented by the input package, not verified against an attached `package.json`. Inspect the scripts first. Use their actual equivalents if they changed, and record that mapping; do not silently drop tests or invent a passing command. Use the checked-in lockfile and the project's documented toolchain. Reproduce the external audit using the command block in the GPU plan when the source is available.

Write fresh evidence under a new run directory, for example `artifacts/validation/p1-m0/<run-id>/`. Record the commit, dirty-tree snapshot, source hashes, tool versions, exact commands, full results, seeds, and benchmark environment. Never overwrite the three supplied audit evidence files. Their reported 24-pass/11-fail result is a historical comparison, not an acceptance target to force onto a changed checkout.

### M1: make the GPU-compatible boundary concrete

Define backend-neutral commands, delayed tick-stamped probes, versioned snapshots, feature eligibility, and explicit units. Add the minimal element/nuclide/species/material identity separation and an extensible component layout. Keep future nuclide populations and chemistry disabled. Do not allocate a 118-value or whole-nuclide-table vector in every cell.

Preserve existing numeric material and tool IDs through an explicit migration. Atomic numbers are not material IDs. Add the isolated circuit corrections described in M1 without using them to delay the minimal fluid reference. Add state-version invalidation tests.

### M2: establish the numerical reference

Implement compatible MAC pressure operators, conservative phase/tracer fluxes, compatible momentum transport, boundaries, viscosity, and stable substeps in a small Float64 CPU world. Stop using legacy cellular fluid motion inside this world from its first step. Validate the GPU plan's fixtures before porting.

### M3: deliver the first usable GPU scene

Port the same stage graph to WGSL/f32, render authoritative GPU fields directly, and use asynchronous small readbacks. Measure actual transfer bytes and allocation sizes. Test no-adapter and device-loss handling. Deliver a selectable experimental scene and CPU/GPU comparisons at equal physical times. No chemistry, phase change, sand, movable solids, nuclear reactions, or resolved shocks belong in this first demonstrator.

Then continue M4-M7 before the normal product sequence moves to P2. M7 promotes only the scene/feature set explicitly agreed and tested for that backend; it does not require future P4-P8 content.

## Working rules for every subsequent phase

A work item progresses through `planned -> in-progress -> implemented -> validated`. `Blocked` records a specific missing dependency or failed gate. Implemented code alone is not validated capability. The planning manifest starts every new phase as `planned`.

Keep one evolving simulation owner per scene. CPU reference worlds are separate test instances. CPU UI, data preparation, commands, and bounded circuit work may cooperate with a GPU backend without owning a second copy of the whole physical world.

Numerical model and execution backend are different choices. `lowMach` and `compressible` are physical models; `cpu` and `webgpu` are execution choices. A late nuclear module does not turn a low-Mach fluid solver into a plasma or shock solver.

Keep new scientific data attributable per property and per nuclide. Unknown is not zero. A coloured catalogue entry is not a validated material. Preserve isotope composition through supported motion, phase changes, chemistry, save/load, and fragmentation.

For each milestone, copy [the evidence template](templates/phase-evidence.md), run its references and regressions, record measured limitations, update the relevant current-model sections, and only then update phase status. Continue to the next milestone when dependencies are satisfied. A hardware-dependent promotion gate can remain blocked while independent CPU work proceeds, but it must not be reported as passed.

## Defaults that allow development to start

Use TypeScript for host/reference code and WebGPU/WGSL for the experimental GPU backend. Preserve the documented 480 x 270 target grid, 0.01 m cell width and represented depth, and 1/60 s outer clock unless a versioned model change is justified. Internal substeps follow stability constraints, not the display frame rate.

Use the GPU plan's bounded water-property model as the provisional development default; record the decision before M4. Do not silently extrapolate it to cryogenic elements, extreme temperatures, or plasma. Hardware-specific performance thresholds are provisional until M0 names the test devices. Neither decision blocks M0-M3.

The user-facing roster grows through 40, 83, 103, and 118 supported identities, with different representation levels. The registry already contains all 118 names. These are development cohorts, not categories of nuclear stability, natural occurrence, or universal bulk-material validity.
