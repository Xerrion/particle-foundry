# Milestone evidence record

Copy this file into the run's durable summary location and fill in actual results. Empty fields mean unrecorded, not passed. Never replace a missing run with an estimate.

## Identity

```text
phase:
milestone:
gate:
status: planned | in-progress | implemented | validated | blocked
run ID:
run date:
source commit:
working-tree snapshot/hash:
input scene and seed:
catalogue/data/network versions:
checkpoint/schema version:
```

## Scope and contracts

Describe what changed, who owns state, which previous behavior was replaced, supported backend/model/material combinations, property domains, and explicit exclusions. Link the controlling plan and source references. Record any deviation from the plan and its numerical/design rationale.

## Environment and commands

```text
OS and architecture:
Bun/Node/TypeScript or other tool versions:
browser and version:
adapter/device information available:
requested features/limits:
exact commands and exit codes:
raw log paths:
```

Mark hardware fields `not run` for a CPU-only milestone. Do not imply GPU execution from shader compilation or screenshots alone.

## Results

| Test/fixture ID | Independent reference | Physical time / scale | Tolerance or statistical criterion | Measured result | Pass / fail / unrun |
| --- | --- | --- | --- | --- | --- |

Report conserved inventory and each relevant energy channel before/after, boundary/brush/source terms, residuals, refinement results, and maximum invalid/negative states. Explain any explicitly approximated mass-defect or pseudo-material term.

## Performance and resource evidence

Record grid, active components, warm-up, sample count, displayed frame p50/p95, simulated seconds per wall second, latency, substeps, iteration/dispatch counts, allocation manifest, transfer bytes and queue sizes. Distinguish measured values from proposed targets.

## Recovery and compatibility

List save/load, schema migration, device-absence/loss, component growth, command ordering, pause/reset, settings and replay tests. State unsupported combinations and whether their rejection was tested.

## Acceptance decision and next work

Explain which exit criteria passed, which are blocked/unrun, the exact next dependency-ready task, and what documentation/manifests were updated. Link raw evidence rather than replacing it with a general success statement. `Validated` requires all applicable gate evidence.
