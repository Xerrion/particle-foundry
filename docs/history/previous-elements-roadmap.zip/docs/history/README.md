# Original input and historical evidence

This documentation revision was made from the uploaded `docs.zip`. No application source was included, and no application checks or GPU measurements were run here.

The complete original archive is preserved byte-for-byte as [original-docs-2026-09-21.zip](original-docs-2026-09-21.zip). It contains the original current-model description, Danish roadmap and delivered history, original plans, HTML presentation, and audit files. It is a preservation copy, not the developer entrypoint.

Original archive SHA-256:

```text
f0c353534cca10736d98c449fa96b5e2ed07c241a3ba7cd4463f897ab9860eb5
```

[original-file-hashes.json](original-file-hashes.json) records every original file's SHA-256 using paths relative to `docs/`.

The following files remain byte-for-byte unchanged at their original paths:

- [audit.cjs](../plans/fluid-gpu-redesign/audit.cjs)
- [current-audit-output.txt](../plans/fluid-gpu-redesign/current-audit-output.txt)
- [current-audit-results.json](../plans/fluid-gpu-redesign/current-audit-results.json)

The historical JSON reports 35 checks: 24 passing and 11 failing. Tool versions, historical source hashes, original path labels, and any first-person measurement statements belong to that earlier audit. They must not be represented as results of this documentation update. New baseline runs use a separate evidence directory and fresh provenance.

Current implementation descriptions remain qualified as documented by the supplied files until a developer confirms them against source. The updated roadmap and matter/nuclear designs supersede the original planning order, not the preserved historical measurements.
